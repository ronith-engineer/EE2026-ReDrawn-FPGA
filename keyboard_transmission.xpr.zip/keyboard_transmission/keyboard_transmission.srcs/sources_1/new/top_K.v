`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: top_K
// Description: KEYBOARD BOARD (Board K) top module.
//              USB keyboard -> keyboard_ctrl -> keys -> link_tx -> tx (J1)
//
//   led[6:0] : keys held on THIS board (should match Board M's led[6:0])
//              bit 0 A, 1 D, 2 Space, 3 Left Shift, 4 R, 5 Esc, 6 Enter
//   btnC     : reset
//
// Files needed in this project:
//   top_K.v, keyboard_ctrl.v, Ps2Interface.vhd, link_tx.v, packet_tx.v, uart_tx.v
//////////////////////////////////////////////////////////////////////////////////

module top_K(
    input clk,              // W5, 100 MHz
    input btnC,             // U18, reset button
    inout PS2Clk,           // C17, keyboard clock
    inout PS2Data,          // B17, keyboard data
    output tx,              // J1 (Pmod JA pin 1), wire to Board M's rx
    output [15:0] led
    );

    // reset button comes from outside, so pass it through 2 flip-flops
    reg [1:0] rst_sync = 2'b11;
    always @ (posedge clk) begin
        rst_sync <= {rst_sync[0], btnC};
    end
    wire rst = rst_sync[1];

    wire [6:0] keys;        // keyboard_ctrl -> link_tx

    keyboard_ctrl u_keyboard (
        .clk      (clk),
        .rst      (rst),
        .ps2_clk  (PS2Clk),
        .ps2_data (PS2Data),
        .keys     (keys)
    );

    link_tx u_link_tx (
        .clk  (clk),
        .rst  (rst),
        .keys (keys),
        .tx   (tx)
    );

    assign led[6:0]  = keys;    // keys pressed on this board
    assign led[15:7] = 9'b0;    // unused

endmodule