`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: top_M
// Description: MAIN BOARD (Board M) top module, LED test version.
//              USB mouse -> MouseCtl                -> left / right buttons
//              rx (J1)   -> link_rx (uart + packet) -> keys from Board K
//
//   led[6:0] : keys received from Board K (should match Board K's led[6:0])
//              bit 0 A, 1 D, 2 Space, 3 Left Shift, 4 R, 5 Esc, 6 Enter
//   led[9]   : link_ok, 1 while good packets are arriving
//   led[13]  : right mouse button held
//   led[15]  : left mouse button held
//   btnC     : reset
//
// Files needed in this project:
//   top_M.v, MouseCtl.vhd, Ps2Interface.vhd, link_rx.v, uart_rx.v, packet_rx.v
//////////////////////////////////////////////////////////////////////////////////

module top_M(
    input clk,              // W5, 100 MHz
    input btnC,             // U18, reset button
    inout PS2Clk,           // C17, mouse clock
    inout PS2Data,          // B17, mouse data
    input rx,               // J1 (Pmod JA pin 1), wire from Board K's tx
    output [15:0] led
    );

    // reset button comes from outside, so pass it through 2 flip-flops
    reg [1:0] rst_sync = 2'b11;
    always @ (posedge clk) begin
        rst_sync <= {rst_sync[0], btnC};
    end
    wire rst = rst_sync[1];

    // ---- mouse ----
    wire left, middle, right;
    wire [11:0] xpos, ypos;     // not used yet (for VGA later)
    wire [3:0] zpos;
    wire new_event;

    MouseCtl u_mousectl (
        .clk       (clk),
        .rst       (rst),
        .xpos      (xpos),
        .ypos      (ypos),
        .zpos      (zpos),
        .left      (left),
        .middle    (middle),
        .right     (right),
        .new_event (new_event),
        .value     (12'd0),     // settings not used: MouseCtl defaults
        .setx      (1'b0),
        .sety      (1'b0),
        .setmax_x  (1'b0),
        .setmax_y  (1'b0),
        .ps2_clk   (PS2Clk),
        .ps2_data  (PS2Data)
    );

    // ---- keys from Board K ----
    wire [6:0] keys_rx;
    wire link_ok;

    link_rx u_link_rx (
        .clk     (clk),
        .rst     (rst),
        .rx      (rx),
        .keys_rx (keys_rx),
        .link_ok (link_ok)
    );

    // ---- LEDs ----
    assign led[6:0]   = keys_rx;   // same LEDs as Board K when the link works
    assign led[8:7]   = 2'b0;
    assign led[9]     = link_ok;
    assign led[12:10] = 3'b0;
    assign led[13]    = right;     // right mouse button
    assign led[14]    = 1'b0;
    assign led[15]    = left;      // left mouse button

endmodule